package unittest.runners;

public class ParameterizedTestRunner extends TestRunner {

    public ParameterizedTestRunner(Class testClass) {
        super(testClass);
        // TODO: complete this constructor
    }

    // TODO: Finish implementing this class
}
